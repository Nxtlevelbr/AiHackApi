﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AiHackApi.Models
{
    [Table("tb_especialidades")]
    public class Especialidade
    {
        [Key]
        [Column("id_especialidade")]
        public int IdEspecialidade { get; set; }

        [Required]
        [Column("nome_especialidade")]
        public string NomeEspecialidade { get; set; }

        // Construtor que assegura que NomeEspecialidade tem um valor válido
        public Especialidade(string nomeEspecialidade)
        {
            NomeEspecialidade = nomeEspecialidade ?? throw new ArgumentNullException(nameof(nomeEspecialidade));
        }

        // Construtor sem parâmetros, caso necessário
        public Especialidade()
        {
            // Inicializando NomeEspecialidade com um valor padrão
            NomeEspecialidade = string.Empty;
        }
    }
}
