﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AiHackApi.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contatos",
                columns: table => new
                {
                    IdContato = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    TelefoneContato = table.Column<string>(type: "NVARCHAR2(20)", maxLength: 20, nullable: false),
                    EmailContato = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    InfoContato = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contatos", x => x.IdContato);
                });

            migrationBuilder.CreateTable(
                name: "Especialidades",
                columns: table => new
                {
                    IdEspecialidade = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    NomeEspecialidade = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    Ativo = table.Column<bool>(type: "BOOLEAN", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Especialidades", x => x.IdEspecialidade);
                });

            migrationBuilder.CreateTable(
                name: "tb_bairros",
                columns: table => new
                {
                    id_bairro = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    nome_bairro = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tb_bairros", x => x.id_bairro);
                });

            migrationBuilder.CreateTable(
                name: "Enderecos",
                columns: table => new
                {
                    IdEndereco = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    LogradouroEnd = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: false),
                    ComplementoEnd = table.Column<string>(type: "NVARCHAR2(200)", maxLength: 200, nullable: true),
                    NumeroEnd = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbBairroIdBairro = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    BairroIdBairro = table.Column<int>(type: "NUMBER(10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Enderecos", x => x.IdEndereco);
                    table.ForeignKey(
                        name: "FK_Enderecos_tb_bairros_BairroIdBairro",
                        column: x => x.BairroIdBairro,
                        principalTable: "tb_bairros",
                        principalColumn: "id_bairro");
                });

            migrationBuilder.CreateTable(
                name: "Medicos",
                columns: table => new
                {
                    IdMedico = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    NmMedico = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    CrmMedico = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbEspecialidadesIdEspecialidade = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbContatosIdContato = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbEnderecosIdEndereco = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    SalarioMedico = table.Column<decimal>(type: "DECIMAL(18, 2)", nullable: false),
                    Ativo = table.Column<bool>(type: "BOOLEAN", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medicos", x => x.IdMedico);
                    table.ForeignKey(
                        name: "FK_Medicos_Contatos_TbContatosIdContato",
                        column: x => x.TbContatosIdContato,
                        principalTable: "Contatos",
                        principalColumn: "IdContato",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Medicos_Enderecos_TbEnderecosIdEndereco",
                        column: x => x.TbEnderecosIdEndereco,
                        principalTable: "Enderecos",
                        principalColumn: "IdEndereco",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Medicos_Especialidades_TbEspecialidadesIdEspecialidade",
                        column: x => x.TbEspecialidadesIdEspecialidade,
                        principalTable: "Especialidades",
                        principalColumn: "IdEspecialidade",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Pacientes",
                columns: table => new
                {
                    IdPaciente = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    NmPaciente = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    DtNascPaciente = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: false),
                    StsPaciente = table.Column<string>(type: "NVARCHAR2(1)", nullable: false),
                    TbTipoPessoaIdTipoPessoa = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbConveniosIdConvenio = table.Column<int>(type: "NUMBER(10)", nullable: true),
                    TbContatosIdContato = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbEnderecosIdEndereco = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    ContatoIdContato = table.Column<int>(type: "NUMBER(10)", nullable: true),
                    EnderecoIdEndereco = table.Column<int>(type: "NUMBER(10)", nullable: true),
                    CPF = table.Column<string>(type: "NVARCHAR2(11)", maxLength: 11, nullable: false),
                    Ativo = table.Column<bool>(type: "BOOLEAN", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pacientes", x => x.IdPaciente);
                    table.ForeignKey(
                        name: "FK_Pacientes_Contatos_ContatoIdContato",
                        column: x => x.ContatoIdContato,
                        principalTable: "Contatos",
                        principalColumn: "IdContato");
                    table.ForeignKey(
                        name: "FK_Pacientes_Enderecos_EnderecoIdEndereco",
                        column: x => x.EnderecoIdEndereco,
                        principalTable: "Enderecos",
                        principalColumn: "IdEndereco");
                });

            migrationBuilder.CreateTable(
                name: "Consultas",
                columns: table => new
                {
                    IdConsulta = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    DataHoraConsulta = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: false),
                    StatusConsulta = table.Column<string>(type: "NVARCHAR2(2000)", nullable: false),
                    TbMedicosIdMedico = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    TbPacientesIdPaciente = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    MedicoIdMedico = table.Column<int>(type: "NUMBER(10)", nullable: true),
                    PacienteIdPaciente = table.Column<int>(type: "NUMBER(10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Consultas", x => x.IdConsulta);
                    table.ForeignKey(
                        name: "FK_Consultas_Medicos_MedicoIdMedico",
                        column: x => x.MedicoIdMedico,
                        principalTable: "Medicos",
                        principalColumn: "IdMedico");
                    table.ForeignKey(
                        name: "FK_Consultas_Pacientes_PacienteIdPaciente",
                        column: x => x.PacienteIdPaciente,
                        principalTable: "Pacientes",
                        principalColumn: "IdPaciente");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Consultas_MedicoIdMedico",
                table: "Consultas",
                column: "MedicoIdMedico");

            migrationBuilder.CreateIndex(
                name: "IX_Consultas_PacienteIdPaciente",
                table: "Consultas",
                column: "PacienteIdPaciente");

            migrationBuilder.CreateIndex(
                name: "IX_Enderecos_BairroIdBairro",
                table: "Enderecos",
                column: "BairroIdBairro");

            migrationBuilder.CreateIndex(
                name: "IX_Medicos_TbContatosIdContato",
                table: "Medicos",
                column: "TbContatosIdContato");

            migrationBuilder.CreateIndex(
                name: "IX_Medicos_TbEnderecosIdEndereco",
                table: "Medicos",
                column: "TbEnderecosIdEndereco");

            migrationBuilder.CreateIndex(
                name: "IX_Medicos_TbEspecialidadesIdEspecialidade",
                table: "Medicos",
                column: "TbEspecialidadesIdEspecialidade");

            migrationBuilder.CreateIndex(
                name: "IX_Pacientes_ContatoIdContato",
                table: "Pacientes",
                column: "ContatoIdContato");

            migrationBuilder.CreateIndex(
                name: "IX_Pacientes_EnderecoIdEndereco",
                table: "Pacientes",
                column: "EnderecoIdEndereco");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Consultas");

            migrationBuilder.DropTable(
                name: "Medicos");

            migrationBuilder.DropTable(
                name: "Pacientes");

            migrationBuilder.DropTable(
                name: "Especialidades");

            migrationBuilder.DropTable(
                name: "Contatos");

            migrationBuilder.DropTable(
                name: "Enderecos");

            migrationBuilder.DropTable(
                name: "tb_bairros");
        }
    }
}
